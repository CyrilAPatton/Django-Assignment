from django.shortcuts import render
from django.shortcuts import redirect




def index(request):
    return render(request, "index.html")

def new(request):
    speed = request.POST['how_fast']
    where = request.POST['where_to']
    car_selected = request.POST['car_list']

    context = {
    	"how_fast": speed,
    	"where_to": where,
    	"car_list": car_selected
    }

    return render(request, "new.html", context)






